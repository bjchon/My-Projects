#include "myHeader1.h"
#ifndef MYHEADER2_H
#define MYHEADER2_H
namespace myNamespace{
    void fun3();
    void fun4();
}

void myNamespace::fun3(){}

void myNamespace::fun4(){}

#endif