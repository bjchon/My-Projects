#ifndef MYHEADER1_H
#define MYHEADER1_H
#include <iostream>
using namespace std;
namespace myNamespace{
    void fun1();
    void fun2();
}

void myNamespace::fun1(){}

void myNamespace::fun2(){}

#endif