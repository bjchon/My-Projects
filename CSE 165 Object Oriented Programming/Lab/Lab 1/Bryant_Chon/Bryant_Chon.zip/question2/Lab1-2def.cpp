#include "Lab1-2.h"

void fun(){
    cout << "Hello void" << endl;
}

char fun(char a){
    cout << "Hello char ";
    return a;
}

int fun(int b){
 cout << "Hello int ";
 return b;
}

float fun(float c){
 cout << "Hello float ";
 return c;
}


