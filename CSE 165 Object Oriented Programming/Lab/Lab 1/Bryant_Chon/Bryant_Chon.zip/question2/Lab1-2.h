#include <iostream>
using namespace std;

void fun();
char fun(char a);
int fun(int b);
float fun(float c);
