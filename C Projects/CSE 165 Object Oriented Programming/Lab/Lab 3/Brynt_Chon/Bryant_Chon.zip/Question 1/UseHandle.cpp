//: C05:UseHandle.cpp
//{L} Handle
// Use the Handle class
#include <iostream>
#include "Handle.h"
int main() {
Handle u1,u2,u3;
Handle(25);
} ///:~