#include "array.h"

 int main(){
    AOI a1 = AOI();
    a1.print();
 }